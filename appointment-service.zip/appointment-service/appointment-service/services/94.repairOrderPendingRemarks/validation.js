const { check, validationResult } = require('express-validator');
const errorDef = require('../services.config/errorDef');

const addData = [
    // check("datas.*.remarkType",`Remark Type parameter is missing`).trim().not().isEmpty(),
]

const updateData = [
    check('id', 'id can not be empty').not().isEmpty()
];

const deleteData = [
    check('ids', 'ids cannot be empty').not().isEmpty().isArray()
]

const addDataValidationRules = () => {
    return addData;
}

const updateDataValidationRules = () => {
    return [
        ...updateData,
        ...addData
    ]
}

const deleteDataValidationRules = () => {
    return [
        ...deleteData
    ]
}

const SearchValidationRules = () => {
    return [
        check('datas', 'datas is empty').not().isEmpty().isArray(),
    ]
}

const validate = (req, res, next) => {
    const errors = validationResult(req)
    if (errors.isEmpty()) {
        return next()
    }
    const extractedErrors = []
    errors.array().map(err => extractedErrors.push({ [err.param]: err.msg }))

    if(extractedErrors.length > 0) {
        let err = errorDef.INVALID_PARAMETER;
        err.errors = extractedErrors;
        throw err
    } else {
        next();
    }
}
module.exports = {
    addDataValidationRules,
    updateDataValidationRules,
    SearchValidationRules,
    deleteDataValidationRules,
    validate,
}