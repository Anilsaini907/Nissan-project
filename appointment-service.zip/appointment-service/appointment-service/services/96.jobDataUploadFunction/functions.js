const jobDataUploadFunction = require('@driveit/driveit-databases/databases/serviceMaster').JobDataUploadFunction;
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const topicSeries = require('../../utilities/topicSeries');
const InternalUserModel = require('@driveit/driveit-databases/databases/auth/models/internalUsers');

class Functions {
    
    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        let pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        let orderBy = [order.columnName, order.direction];


        return jobDataUploadFunction.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond).then(async (jobDataUploadRes) => {
            
            let internalUserIds = _.without(_.uniq(_.map(jobDataUploadRes.rows, 'uploadedById')), '', null);
            let filterInternalUser = [{ colId: 'id', text: !_.isEmpty(internalUserIds) ? internalUserIds : ['00000000-0000-0000-0000-000000000000'] }];
            let internalUserRes = await InternalUserModel.searchAll([], ['id', 'email', 'employeeId', 'fullName', 'updatedAt'], {}, ['updatedAt', 'desc'], filterInternalUser, true, false, true);
            let internalUsers = internalUserRes ? _.map(internalUserRes, 'dataValues') : [];

            _.forEach(jobDataUploadRes.rows, (rw) => {
                let foundUploadBy = _.find(internalUsers, (o) => { return o.id === rw.uploadedById; });
                rw.dataValues['uploadedBy'] = foundUploadBy ? foundUploadBy : null;
            });

            return {
                ...jobDataUploadRes
            };
        });
    }
    
    static async addMany(datas, who, headers) {
        return this.getGenerateMultipleCode(headers, _.size(datas)).then((generatedCodes) => {
            var promises = [];

            if (_.size(generatedCodes) === _.size(datas)) {
                _.forEach(datas, (data, index) => {

                    promises.push(Functions.add(data, who, headers, generatedCodes[index]).catch((error) => {
                        return errorDef.compileError(error);
                    }));
                });
            }

            return Promise.all(promises);
        });
    }

    static async add(data, who, headers, vehicleUploadNo) {
        const record = {
            ...data,
            idNo: vehicleUploadNo,
            updatedBy: who,
            createdBy: who
        };

        return jobDataUploadFunction.addRecord(record);
    }

    static async getGenerateMultipleCode(headers, howMany) {
        // Comment out - because not exist this method anymore, please try another later
        // let code = "VEHICLEUPLOAD";
        // return topicSeries.generateMultipleSeries(code, headers, howMany).then((s) => {
        //     if (s.status && s.code && s.message) {
        //         return Promise.reject(s);
        //     } else {
        //         return s;
        //     }

        // }).catch(function (err) {
        //     return Promise.reject(err);
        // });

        return Promise.reject([]);
    }

    static async update(id, education, who) {
        const where = {
            id
        };
        education['updatedBy'] = who;
        education['id'] = id;

        return jobDataUploadFunction.updateRecord(education, where).then((results) => {
            console.log(results);
            return VehicleUpload.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        };

        if (option === 'hard') {
            return jobDataUploadFunction.deleteRecord(where).then((results) => {
                return jobDataUploadFunction.getOne(where);
            });
        } else if (option === 'soft') {
            const education = {
                deleted: true,
                updatedBy: who
            };

            return jobDataUploadFunction.updateRecord(education, where).then((results) => {
                return jobDataUploadFunction.getOne(where);
            });
        } else if (option === 'restore') {
            const education = {
                deleted: false,
                updatedBy: who
            };

            return jobDataUploadFunction.updateRecord(education, where).then((results) => {
                return jobDataUploadFunction.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;