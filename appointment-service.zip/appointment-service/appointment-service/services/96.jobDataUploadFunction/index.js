const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

/**
 * Search for Vehicle Upload listing
 * 
 * @route POST /vehicleUploadFunction/search
 * @operationId vehicleUploadFunctionSearch
 * @group Vehicle Upload API
 * @param {VehicleUploadFunctionSearch.model} VehicleUploadFunctionSearch - Search. Show all if not provided.
 * @returns {VehicleUploadFunctionSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Vehicle Upload Function service
 * 
 * @route POST /vehicleUploadFunction/add
 * @operationId addVehicleUploadFunction
 * @group Vehicle Upload Function API
 * @param {AddVehicleUploadFunction.model} AddVehicleUpload.body.required - required AddVehicleUploadFunction
 * @returns {Array.<VehicleUploadFunctionData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/add', async function (req, res, next) {
    const datas = req.body.datas;
    const headers = req.headers;
    
    errorDef.parameterHandler([datas]);
    _.forEach(datas, (jobDataUploadObj) => {
        errorDef.parameterHandler([
            jobDataUploadObj.status,
            jobDataUploadObj.fileName,
            jobDataUploadObj.fileURL,
            jobDataUploadObj.fileStatusErrors,
            jobDataUploadObj.uploadedById,
            jobDataUploadObj.uploadStartTime,
            jobDataUploadObj.uploadEndTime
        ]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(datas, userInfo.id, headers).then((result) => {
            return res.status(200).send(result);
        })
        .catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;