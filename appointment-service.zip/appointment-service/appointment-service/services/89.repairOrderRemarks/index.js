const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
const { addDataValidationRules, updateDataValidationRules, validate, SearchValidationRules, deleteDataValidationRules } = require('./validation')

/**
 * Search for preRepairOrderFlatRate listing
 * 
 * @route POST /preRepairOrderFlatRate/search
 * @operationId preRepairOrderFlatRateSearch
 * @group preRepairOrderFlatRate API
 * @param {preRepairOrderFlatRateSearch.model} preRepairOrderFlatRateSearch.body - Search. Show all if not provided.
 * @returns {preRepairOrderFlatRateSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add preRepairOrderFlatRate
 * 
 * @route PUT /preRepairOrderFlatRate/add
 * @operationId preRepairOrderFlatRateAdd
 * @group preRepairOrderFlatRate API
 * @param {AddpreRepairOrderFlatRate.model} AddpreRepairOrderFlatRate.body.required - required AddpreRepairOrderFlatRate
 * @returns {Array.<preRepairOrderFlatRateData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add', async function (req, res, next) {
    const datas = req.body.datas;

    errorDef.parameterHandler([datas]);
    datas.forEach((preRepairOrderFlatRate) => {
        errorDef.parameterHandler([
            preRepairOrderFlatRate.code,
        ]);
    })
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(datas, userInfo.id).then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
});

/**
 * Update preRepairOrderFlatRate
 * 
 * @route PUT /preRepairOrderFlatRate/update
 * @operationId preRepairOrderFlatRateUpdate
 * @group preRepairOrderFlatRate API
 * @param {UpdatepreRepairOrderFlatRate.model} UpdatepreRepairOrderFlatRate.body.required - required UpdatepreRepairOrderFlatRate
 * @returns {preRepairOrderFlatRateData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update', async function (req, res, next) {
    const id = req.body.id;
    const data = req.body.data;

    errorDef.parameterHandler([id, data]);

    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.update(id, data, userInfo.id).then((record) => {
            if (!record) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete preRepairOrderFlatRate
 * 
 * @route DELETE /preRepairOrderFlatRate/delete
 * @operationId preRepairOrderFlatRateDelete
 * @group preRepairOrderFlatRate API
 * @param {DeletepreRepairOrderFlatRate.model} DeletepreRepairOrderFlatRate.body.required - required DeletepreRepairOrderFlatRate
 * @returns {preRepairOrderFlatRateData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', deleteDataValidationRules(), validate,async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;