const { check, validationResult } = require('express-validator');
const errorDef = require('../services.config/errorDef');

const addData = [
    check('datas', 'datas is empty').not().isEmpty().isArray() 
]

const updateData = [
    check('id', 'id can not be empty').not().isEmpty()
];

const deleteData = [
    check('ids', 'ids cannot be empty').not().isEmpty().isArray()
]

const addDataValidationRules = () => {
    return [
        ...addData
    ]
}

const updateDataValidationRules = () => {
    return [
        ...updateData,        
    ]
}

const deleteDataValidationRules = () => {
    return [
        ...deleteData
    ]
}

const searchValidationRules = () => {
    return [
        check('datas', 'datas is empty').not().isEmpty().isArray(),            
    ]
}

const validate = (req, res, next) => {
    const errors = validationResult(req)
    if (errors.isEmpty()) {
        return next()
    }
    let extractedErrors = '';
    errors.array().map(err => extractedErrors = extractedErrors + '  \n   ' + err.msg)

    return res.status(400).json({
        status: 400,
        code: 'Invalid Parameter',
        message: extractedErrors,   
    })
}

module.exports = {
    addDataValidationRules,
    updateDataValidationRules,
    searchValidationRules,
    deleteDataValidationRules,
    validate,
}