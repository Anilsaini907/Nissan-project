const TopicSeries = require('@driveit/driveit-databases/databases/generalMaster/models/15.topic-series');

var _ = require('lodash');
const Sequelize = require("sequelize");
const errorDef = require("../services.config/errorDef")
const Utils = require('@driveit/driveit-databases/utils/database.utils');
const Status = require('@driveit/driveit-databases/databases/generalMaster/models/enums/Status');
const moment = require('moment');

class Functions {

    static async generateCode(code, who) {
        let prefix, startNumber, endNumber;
        switch (code) {
            case "VEHICLETRANSFER":
                prefix = 'TR',
                startNumber = '00000000',
                endNumber = "99999999";
            break;
            case "BDO":
                prefix = 'BDO',
                startNumber = '00000',
                endNumber = "99999";
            break;
            case "TDO":
                prefix = 'TDO',
                startNumber = '00000000',
                endNumber = "99999";
            break;
            case "PDIDO":
                prefix = 'PDIDO',
                startNumber = '00000',
                endNumber = "99999";
            break;
            case "TRO":
                prefix = 'TRO',
                startNumber = '00000',
                endNumber = "99999";
            break;

            case "VEHICLEBOOKING":
                prefix = "BO";
                startNumber = "0000000000";
                endNumber = "9999999999";
                break;
            case "VEHICLEUPLOAD":
                prefix = "";
                startNumber = "000000000000";
                endNumber = "999999999999";
                break;
            case "AFL":
            case "AFD":
            case "ADL":
                prefix = "";
                startNumber = "000000000";
                endNumber = "999999999";
                break;
            default:
                prefix = "";
                startNumber = "0000000";
                endNumber = "9999999";
                break;
        }
        let topicSeries = {
            code,
            prefix,
            startNumber,
            endNumber,
            status: "enabled",
            createdBy: who,
            updatedBy: who
        };

        return TopicSeries.addRecord(topicSeries);
    }

    static async generateSeries(code, customizedPrefix = null) {
        const where = { code, deleted: false, status: Status.ENABLED };
        return TopicSeries.sequelize.transaction({
            isolationLevel: Sequelize.Transaction.SERIALIZABLE
        }, function (transaction) {
            return TopicSeries.getOne(where, transaction).then((existingRecord) => {

                if (!existingRecord) {
                    throw errorDef.NOT_FOUND;
                }

                if (!existingRecord.currentNumber) {
                    existingRecord.currentNumber = existingRecord.startNumber;
                }

                const numberLength = existingRecord.currentNumber.length;
                let incrementedNumber = (+existingRecord.currentNumber) + 1;
                incrementedNumber = Utils.leadingZeros(incrementedNumber, numberLength);

                const payload = { id: existingRecord.id, currentNumber: incrementedNumber }

                return TopicSeries.updateRecord(payload, where, transaction).then((updated) => {
                    if (updated) {
                        return TopicSeries.getOne(where, transaction).then((newRecord) => {
                            if (newRecord.prefix !== null && newRecord.prefix !== "") {
                                return newRecord.prefix + newRecord.currentNumber;
                            } else {
                                if (customizedPrefix !== null && customizedPrefix !== "") {
                                    return customizedPrefix + newRecord.currentNumber;
                                } else {
                                    return newRecord.currentNumber;
                                }
                            }
                        });
                    }
                    throw errorDef.UPDATE_FAILED;
                });
            });

        });
    }

    static async generateSeriesMultiple(code, qty, customizedPrefix) {
        const where = { code, deleted: false, status: Status.ENABLED };
        
        let topic = await TopicSeries.getOne(where);
        if (!topic) {
            topic = await this.generateCode(code, 'system');
        }

        const nextRunning = this.getNextRunningNumber(topic, +qty, customizedPrefix);
        await TopicSeries.updateRecord({ currentNumber: nextRunning.incrementedNumber }, { id: topic.id });

        return nextRunning.documentNumbers;
    }

    static getNextRunningNumber(topic, qty, customizedPrefix = null) {
        // nextNumber
        let nextNumber = !topic.currentNumber ? +topic.startNumber + qty : +topic.currentNumber + qty;
        
		const isNewYear = moment().format('YYYY') > +(new Date(topic.updatedAt).getFullYear());
		if (isNewYear && topic.resetPerYr) {
			nextNumber = qty;
        }

        // Prefix
        let prefix = '';
        if (!!customizedPrefix) {
            prefix = customizedPrefix.trim();
        }

        if (!!topic.prefix) {
            prefix = topic.prefix.trim();
        }

        // Prefix Year
		const yearPrefix = (topic.yearSuffix) ? moment().format('YY') : '';

        // Incremented Number
        const numberLength = !topic.currentNumber ? topic.startNumber.length : topic.currentNumber.length;
        const incrementedNumber = Utils.leadingZeros(nextNumber, numberLength);

        if (qty > 1) {
            let documentNumbers = [];
            let startNo = +incrementedNumber - (qty - 1);

            for (let i = 0; i < qty; i++) {
                let generated = Utils.leadingZeros(startNo + i, numberLength);

                documentNumbers.push(prefix + yearPrefix + generated);
            }

            return { incrementedNumber, documentNumbers };
        }

        return { 
            incrementedNumber: incrementedNumber,
            documentNumbers: [prefix + yearPrefix + incrementedNumber]
        };
    }

}

module.exports = Functions;