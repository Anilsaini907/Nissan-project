const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');

/**
 * Get MDM Export Data by Raw SQL 
 * 
 * @route POST /mdmExport/get
 * @operationId MDMExportGet
 * @group MDM EXPORT API
 * @param {MDMExport.model} MDMExport.body
 * @returns {MDMExportData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */

router.post('/get', async function (req, res, next) {
    const mdmInfo = req.body.mdmInfo;
    const whereStatement = req.body.mdmInfo.whereStatementsSql;
    const orderStatement = req.body.mdmInfo.orderStatement;
    const joinStatement = req.body.mdmInfo.joinStatement;
    const offset = '';
    const limit = '';
  
    // errorDef.parameterHandler(id);
  
    return functions.getMdmExportData(mdmInfo, whereStatement, orderStatement, joinStatement, offset, limit)
      .then((response) => {
        if (!response) {
          throw errorDef.MASTERDATA_NOT_FOUND
        }
        return res.status(200).send(response);
      })
      .catch((reason) => next(reason));
  });

module.exports = router;