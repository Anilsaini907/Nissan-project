const db = require('@driveit/driveit-databases/databases/serviceMaster');
const Sequelize = require('sequelize');


class Functions {

    static async getMdmExportData(mdmInfo, whereStatement, orderStatement, offset, limit) {
      const sqlStatement = this.getSql(mdmInfo, whereStatement, orderStatement, offset, limit);
      const result = await db.sequelize.query(sqlStatement, { type: Sequelize.QueryTypes.SELECT });
      return result;
    }

    static getSql(mdmInfo, whereStatement, orderStatement, joinStatement, offset, limit){
      let sql = `
      SELECT ${mdmInfo.columnMappingConverted} FROM ${mdmInfo.schema}.${mdmInfo.table} ${mdmInfo.brandName}
      ${joinStatement}
      WHERE ${whereStatement}
      ` 
      if (orderStatement){
        sql = sql + `ORDER BY ${orderStatement}`;
      }
      return sql;
    }

    
}

module.exports = Functions;