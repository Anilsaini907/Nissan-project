const https = require('https');
const http = require('http');
const config = require('config');
var _ = require('lodash');

class EmailAPI {
    static async httpsPost({
        body,
        ...options
    }) {
        return new Promise((resolve, reject) => {
            const req = https.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    try {
                        body = JSON.parse(body);
                        resolve(body)
                    } catch (error) {
                        resolve(body)
                    }
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async httpPost({
        body,
        ...options
    }) {
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => {
                    chunks.push(data)
                })
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    // body = JSON.parse(body);
                    resolve('body')
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async executeApi(body, token = null, headers = null) {
        const obj = {
            hostname: config.emailService.hostname,
            path: config.emailService.sendEmail,
            method: 'POST',
            headers: {
                // 'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };

        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.emailService.port;
            return this.httpPost(obj);
        } else {
            return this.httpsPost(obj);
        }
    }
}

module.exports = EmailAPI;