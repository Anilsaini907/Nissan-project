const https = require('https');
const http = require('http');
const config = require('config');
var _ = require('lodash');
var md5 = require('md5');

const smsAccount = JSON.parse(process.env.sms);

class SMSAPI {
    static async httpsPost({
        body,
        ...options
    }) {
        return new Promise((resolve, reject) => {
            const req = https.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    try {
                        // body = JSON.parse(body);
                        resolve(body)
                    } catch (error) {
                        resolve(body)
                    }
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async httpPost({
        body,
        ...options
    }) {
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => {
                    console.log(data)
                    chunks.push(data)
                })
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    // body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async executeApi(body, token = null, headers = null) {
        const tokenDefault = md5(smsAccount.apiKey);
        const obj = {
            hostname: config.smsService.hostname,
            path: config.smsService.sendSMS,
            method: 'POST',
            headers: {
                'Authorization': `${token ? token : tokenDefault}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.smsService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }
}
module.exports = SMSAPI;