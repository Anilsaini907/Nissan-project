const https = require('https');
const http = require('http');
const config = require('config');
var _ = require('lodash');

// const generalMasterDB = require("@driveit/driveit-databases/databases/generalMaster");
const generalMasterFunctions = require("@driveit/driveit-databases/functions/generalMaster/functions");

class GeneralAPI {
    static async httpsReq({ body, ...options }) {
        return new Promise((resolve, reject) => {
            const req = https.request({
                method: options.method,
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async httpReq({ body, ...options }) {
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: options.method,
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    // if (process.env.NODE_ENV === 'development-local') {
                        body = JSON.parse(body);
                    // } else {
                    //     body = body;
                    // }
                    
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async generalService(token, body, options) {
        let obj = {
            hostname: config.generalCache.hostname,
            path: options.endpoint,
            method: options.method,
            headers: {
                'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.generalCache.port;
            return await this.httpReq(obj);
        } else {
            return await this.httpsReq(obj);
        }
    }

    static async getGeneralData(token, body) {
        let obj = {
            hostname: config.generalCache.hostname,
            path: config.generalCache.getGeneralDataPath,
            method: 'POST',
            headers: {
                'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.generalCache.port;
            return await this.httpReq(obj);
        } else {
            return await this.httpsReq(obj);
        }
    }

    static async getGeneralDataByIds(token, body) {
        let obj = {
            hostname: config.generalCache.hostname,
            path: config.generalCache.getGeneralDataByIdsPath,
            method: 'POST',
            headers: {
                'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.generalCache.port;
            return await this.httpReq(obj);
        } else {
            return await this.httpsReq(obj);
        }
    }

    static async getGeneralDataByQuery(token, body) {
        let obj = {
            hostname: config.generalCache.hostname,
            path: config.generalCache.getGeneralDataByQueryPath,
            method: 'POST',
            headers: {
                'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.generalCache.port;
            return await this.httpReq(obj);
        } else {
            return await this.httpsReq(obj);
        }
    }

    static async masterdataResult(masterdataTypes, token = null) {
        return this.getMasterDataGeneral(masterdataTypes, token).then((res) => {
            let returnRes = {};
            _.forEach(masterdataTypes, (masterdatayType) => {
                _.forEach(res, (r) => {
                    if (r[masterdatayType] !== undefined) {
                        returnRes[masterdatayType] = r[masterdatayType];
                    }
                });
            });

            return returnRes;
        });
    }

    static async processMasterdataResult(rows, masterdataTypes, token = null) {
        let promises = [];
        let masterdataIds = {};
        _.forEach(masterdataTypes, (masterdatayType) => {
            masterdataIds[masterdatayType] = []; // init array object
        });
        _.forEach(rows, (row) => {
            _.forEach(masterdataTypes, (masterdatayType) => {
                let mdIdStr = `${masterdatayType}Id`;
                masterdataIds[masterdatayType].push(row[mdIdStr]);
            });
        });
        _.forEach(masterdataTypes, (masterdatayType) => {
            let p = this.getMasterDataByIds(masterdatayType, masterdataIds[masterdatayType], token);
            promises.push(p);
        });
        return Promise.all(promises).then((res) => {
            let returnRes = {};
            let index = 0;
            _.forEach(masterdataTypes, (masterdatayType) => {
                returnRes[masterdatayType] = res[index++];
            });

            return returnRes;
        }).catch(err => console.log(err));
    }

    static async getMasterDataGeneral(masterdataTypes, token = null) {

        let body = {
            "data": masterdataTypes,
        };

        // return await this.getGeneralData(token, body);
        return await generalMasterFunctions.getData(body.data);
    }

    static async getMasterDataByIds(masterdataType, IdArr, token = null) {
        let body = {
            "data": [{
                "masterdata": masterdataType,
                "ids": IdArr,
            }]
        };
        // return await this.getGeneralDataByIds(token, body);
        return await generalMasterFunctions.getDataByIds(body.data);
    }

    static async getMasterDataByQuery(searchMasterDatas, token = null) {
        _.forEach(searchMasterDatas, (o) => {
            o['skipCount'] = true;
        });
        // let body = {
        //     "data": searchMasterDatas
        // };
        // return await this.getGeneralDataByQuery(token, body);
        return await generalMasterFunctions.getDataByQuery(searchMasterDatas);
    }

    static processRowRecords(recordResults, cacheResults, getWhole = false) {
        _.forEach(recordResults.rows, (row) => {
            let mObj = {};
            _.forEach(cacheResults, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if (c && c.id) {
                        return _.isEqual(c.id, row[masterDataIdStr]);
                    } else {
                        return null;
                    }
                });

                if (mObj[key]) {

                    if (getWhole) {
                        row.dataValues[`${key}`] = mObj[key];
                    } else {
                        if (mObj[key].name) {
                            row.dataValues[`${key}Name`] = mObj[key].name;
                        }
                        if (mObj[key].code) {
                            row.dataValues[`${key}Code`] = mObj[key].code;
                        }
                    }

                }
            });

        });
    }

    static processRowRecordsFor(recordResults, cacheResults, getWhole = false) {
        _.forEach(recordResults.rows, (row) => {
            let mObj = {};
            _.forEach(cacheResults, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if (c && c.id) {
                        return _.isEqual(c.id, row.dataValues[masterDataIdStr]);
                    } else {
                        return null;
                    }
                });

                if (mObj[key]) {

                    if (getWhole) {
                        row.dataValues[`${key}`] = mObj[key];
                    } else {
                        if (mObj[key].name) {
                            row.dataValues[`${key}Name`] = mObj[key].name;
                        }
                        if (mObj[key].code) {
                            row.dataValues[`${key}Code`] = mObj[key].code;
                        }
                    }

                }
            });

        });
    }

    static async processResultsById(rows, cacheKey, token = null, headers = null) {
        let promises = [];
        let dataIds = {};
        _.forEach(cacheKey, (key) => {
            dataIds[key.rowKey ? key.rowKey : key] = []; // init array object
        });
        _.forEach(rows, (row) => {
            if (row.dataValues) {
                _.forEach(cacheKey, (key) => {
                    let mdIdStr = `${key.rowKey ? key.rowKey : key}Id`;
                    if (row.dataValues[mdIdStr]) {
                        dataIds[key.rowKey ? key.rowKey : key].push(row.dataValues[mdIdStr]);
                    }
                });
            } else {
                _.forEach(cacheKey, (key) => {
                    let mdIdStr = `${key.rowKey ? key.rowKey : key}Id`;
                    dataIds[key.rowKey ? key.rowKey : key].push(row[mdIdStr]);
                });
            }
        });
        _.forEach(cacheKey, (key) => {
            let p = this.getMasterDataByIds(key.cacheKey ? key.cacheKey : key, dataIds[key.rowKey ? key.rowKey : key], token);
            promises.push(p);
        });
        return Promise.all(promises).then((res) => {
            let returnRes = {};
            let index = 0;
            _.forEach(cacheKey, (key) => {
                returnRes[key.rowKey ? key.rowKey : key] = res[index++];
            });

            return returnRes;
        });
    }

    static async postProcessingResults(rows, results, flatten = false) {
        _.forEach(rows, (row) => {
            let mObj = [];
            _.forEach(results, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if (c && c.id) {
                        if (row.dataValues[masterDataIdStr]) {
                            return _.isEqual(c.id, row.dataValues[masterDataIdStr]);
                        } else {
                            return _.isEqual(c.id, row[masterDataIdStr]);
                        }
                    } else {
                        return null;
                    }
                });

                if (mObj[key]) {
                    if (flatten) {
                        _.forEach(mObj[key], (v, k) => {
                            let titleCaseKey = k.replace(/(^[a-z])|(\s+[a-z])/g, txt => txt.toUpperCase());
                            let tempStr = `${key}${titleCaseKey}`;
                            row.dataValues[tempStr] = v;
                        })
                    } else {
                        row.dataValues[key] = mObj[key];
                        if (mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    }
                } else {
                    row.dataValues[key] = null;
                }
            });
        });
        return rows;
    }

}
module.exports = GeneralAPI;