/**
 * @typedef YearlyCalendarPublicHolidaySearch
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef YearlyCalendarPublicHolidaySearchResult
 * @property {Array.<YearlyCalendarPublicHolidayData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

 /**
 * @typedef YearlyCalendarPublicHolidayData
 * @property {string} id.required
 * @property {string} calendarDate.required
 * @property {string} holidayType.required
 * @property {string} holidayName.required
 * @property {string} stateId.required
 * @property {string} stateName
 * @property {string} stateCode
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 * @property {string} yearlyCalendarId.required
 */

/**
 * @typedef AddYearlyCalendarPublicHoliday
 * @property {Array.<YearlyCalendarPublicHolidayAddEditData>} yearlyCalendarPublicHoliday.required
 */

/**
 * @typedef UpdateYearlyCalendarPublicHoliday
 * @property {string} id.required
 * @property {YearlyCalendarPublicHolidayAddEditData.model} yearlyCalendarPublicHoliday.required
 */

 /**
 * @typedef DeleteYearlyCalendarPublicHoliday
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef YearlyCalendarPublicHolidayAddEditData
 * @property {string} calendarDate.required
 * @property {string} holidayType.required
 * @property {string} holidayName.required
 * @property {string} stateId.required
 * @property {string} yearlyCalendarId.required
 */