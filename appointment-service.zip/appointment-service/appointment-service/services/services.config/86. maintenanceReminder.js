/**
 * @typedef MaintenanceReminderSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */

/**
 * @typedef MaintenanceReminderSearchResult
 * @property {Array.<MaintenanceReminderData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
* @typedef MaintenanceReminderData
* @property {string} id.required
* @property {string} makeId
* @property {string} modelId
* @property {string} jobId
* @property {string} materialMasterBasicinfoId
* @property {number} nextRecommendMileage
* @property {number} nextRecommendPeriod
* @property {string} nextRecommendPeriodUom
* @property {enum} status - Status option - eg: enabled, disabled
* @property {boolean} deleted - Deleted option - eg: 0, 1
* @property {string} createdBy
* @property {string} createdAt
* @property {string} updatedBy
* @property {string} updatedAt
*/
