/**
 * @typedef TimeRecordingEventTypeGroupData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required 
 * @property {string} timeRecordingEventTypeIds
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */

/**
 * @typedef TimeRecordingEventTypeGroupSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef TimeRecordingEventTypeGroupSearchResult
 * @property {Array.<TimeRecordingEventTypeGroupData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteTimeRecordingEventTypeGroup
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef TimeRecordingEventTypeGroupAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {string} timeRecordingEventTypeIds
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 */

/**
 * @typedef AddTimeRecordingEventTypeGroup
 * @property {Array.<TimeRecordingEventTypeGroupAddEditData>} datas.required
 */

/**
 * @typedef UpdateTimeRecordingEventTypeGroup
 * @property {string} id.required
 * @property {TimeRecordingEventTypeGroupAddEditData.model} data.required
 */