/**
 * @typedef TimeRecordingEventTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef TimeRecordingEventTypeSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef TimeRecordingEventTypeSearchResult
 * @property {Array.<TimeRecordingEventTypeData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteTimeRecordingEventType
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef TimeRecordingEventTypeAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddTimeRecordingEventType
 * @property {Array.<TimeRecordingEventTypeAddEditData>} datas.required
 */

/**
 * @typedef UpdateTimeRecordingEventType
 * @property {string} id.required
 * @property {TimeRecordingEventTypeAddEditData.model} data.required
 */