/**
 * @typedef FlatRateData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {integer} amount.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt  
 */


/**
 * @typedef FlatRateSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef FlatRateSearchResult
 * @property {Array.<FlatRateData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteFlatRate
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef FlatRateAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddFlatRate
 * @property {Array.<FlatRateAddEditData>} datas.required
 */

/**
 * @typedef UpdateFlatRate
 * @property {string} id.required
 * @property {FlatRateAddEditData.model} data.required
 */