/**
 * @typedef TimeRecordingTerminalData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */

/**
 * @typedef TimeRecordingTerminalSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef TimeRecordingTerminalSearchResult
 * @property {Array.<TimeRecordingTerminalData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteTimeRecordingTerminal
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef TimeRecordingTerminalAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddTimeRecordingTerminal
 * @property {Array.<TimeRecordingTerminalAddEditData>} datas.required
 */

/**
 * @typedef UpdateTimeRecordingTerminal
 * @property {string} id.required
 * @property {TimeRecordingTerminalAddEditData.model} data.required
 */