/**
 * @typedef AppointmentTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} hoursPreBlocked.required
 * @property {string} inactivateReason 
 * @property {string} servicePackageIds
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef AppointmentTypeSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef AppointmentTypeSearchResult
 * @property {Array.<AppointmentTypeData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteAppointmentType
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef AppointmentTypeAddEditData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} hoursPreBlocked.required 
  * @property {string} inactivateReason 
  * @property {string} servicePackageIds
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddAppointmentType
 * @property {Array.<AppointmentTypeAddEditData>} datas.required
 */

/**
 * @typedef UpdateAppointmentType
 * @property {string} id.required
 * @property {AppointmentTypeAddEditData.model} datas.required
 */