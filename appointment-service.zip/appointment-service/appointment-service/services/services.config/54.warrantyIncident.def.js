/**
 * @typedef WarrantyIncidentData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt  
 */


/**
 * @typedef WarrantyIncidentSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef WarrantyIncidentSearchResult
 * @property {Array.<WarrantyIncidentData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteWarrantyIncident
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef WarrantyIncidentAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddWarrantyIncident
 * @property {Array.<WarrantyIncidentAddEditData>} datas.required
 */

/**
 * @typedef UpdateWarrantyIncident
 * @property {string} id.required
 * @property {WarrantyIncidentAddEditData.model} data.required
 */