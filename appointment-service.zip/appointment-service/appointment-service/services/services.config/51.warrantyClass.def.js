/**
 * @typedef WarrantyClassData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt  
 */


/**
 * @typedef WarrantyClassSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef WarrantyClassSearchResult
 * @property {Array.<WarrantyClassData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteWarrantyClass
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef WarrantyClassAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddWarrantyClass
 * @property {Array.<WarrantyClassAddEditData>} datas.required
 */

/**
 * @typedef UpdateWarrantyClass
 * @property {string} id.required
 * @property {WarrantyClassAddEditData.model} data.required
 */