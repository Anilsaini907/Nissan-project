/**
 * @typedef RepairOrderTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef RepairOrderTypeSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef RepairOrderTypeSearchResult
 * @property {Array.<RepairOrderTypeData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteRepairOrderType
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef RepairOrderTypeAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddRepairOrderType
 * @property {Array.<RepairOrderTypeAddEditData>} datas.required
 */

/**
 * @typedef UpdateRepairOrderType
 * @property {string} id.required
 * @property {RepairOrderTypeAddEditData.model} datas.required
 */