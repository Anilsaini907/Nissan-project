/**
 * @typedef AppointmentRulesSearch
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef AppointmentRulesSearchResult
 * @property {Array.<AppointmentRulesData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

 /**
 * @typedef AppointmentRulesData
 * @property {string} id.required
 * @property {string} countryId.required
 * @property {CountryData.model} country
 * @property {string} companyId.required
 * @property {string} companyName
 * @property {CompanyData.model} company
 * @property {string} branchId.required
 * @property {string} branchName
 * @property {BranchData.model} branch
 * @property {string} leadDateTime
 * @property {boolean} overBooking.required
 * @property {string} leadTime.required
 * @property {number} leadTimeValue.required
 * @property {number} walkInAllocationForSAHour.required
 * @property {number} walkInAllocationForTechnicianHour.required
 * @property {string} monday.required
 * @property {string} tuesday.required
 * @property {string} wednesday.required
 * @property {string} thursday.required
 * @property {string} friday.required
 * @property {string} saturday.required
 * @property {string} sunday.required
 * @property {string} inactivateReason
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */

/**
 * @typedef AddAppointmentRules
 * @property {Array.<AppointmentRulesAddEditData>} appointmentRules.required
 */

/**
 * @typedef UpdateAppointmentRules
 * @property {string} id.required
 * @property {AppointmentRulesAddEditData.model} appointmentRule.required
 */

 /**
 * @typedef DeleteAppointmentRules
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef AppointmentRulesAddEditData
 * @property {string} countryId.required
 * @property {string} companyId.required
 * @property {string} branchId.required
 * @property {string} leadDateTime
 * @property {boolean} overBooking.required
 * @property {string} leadTime.required
 * @property {number} leadTimeValue.required
 * @property {number} walkInAllocationForSAHour.required
 * @property {number} walkInAllocationForTechnicianHour.required
 * @property {string} monday.required
 * @property {string} tuesday.required
 * @property {string} wednesday.required
 * @property {string} thursday.required
 * @property {string} friday.required
 * @property {string} saturday.required
 * @property {string} sunday.required 
 * @property {string} inactivateReason
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 */

/**
 * @typedef CountryData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} citizenship.required
 * @property {string} timezoneId
 * @property {string} languageId
 * @property {string} currencyId
 * @property {string} status.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */

 /**
 * @typedef CompanyData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} languageId.required
 * @property {string} timezoneId.required
 * @property {string} postcodeId.required
 * @property {string} countryId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} currencyId.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} zone.required
 * @property {string} area.required
 * @property {string} regionId.required
 * @property {string} taxId.required
 * @property {string} taxZone.required
 * @property {string} companyRegistrationNo.required
 * @property {string} taxClassification.required
 * @property {string} taxRegistrationDate.required
 * @property {string} status.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 * @property {boolean} isExternalDealer.required
 * @property {string} parentCompanyId.required
 */

/**
 * @typedef BranchData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} countryId.required
 * @property {string} companyRegistrationNo.required
 * @property {string} status.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} postcodeId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} currencyId.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} zone.required
 * @property {string} area.required
 * @property {string} regionId.required
 * @property {string} taxId.required
 * @property {string} taxRegistrationDate.required
 * @property {string} taxZone.required
 * @property {string} taxclassId.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */