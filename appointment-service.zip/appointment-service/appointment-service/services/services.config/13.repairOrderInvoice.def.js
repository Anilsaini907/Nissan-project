/**
 * @typedef RepairOrderInvoiceData
 * @property {string} id.required
 * @property {string} invoiceNo.required
 * @property {string} invoiceType.required  - Invoice Type option - eg: servicetax,commercial
 * @property {string} pdfPath.required 
 * @property {string} repairOrderId.required 
 * @property {enum} status.required - Status option - eg: final,paid,cancelled
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} updatedByName
 * @property {string} createdBy
 * @property {string} createdByName
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef RepairOrderInvoiceSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef RepairOrderInvoiceSearchResult
 * @property {Array.<RepairOrderInvoiceData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteRepairOrderInvoice
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef RepairOrderInvoiceAddEditData
 * @property {string} invoiceNo.required
 * @property {enum} invoiceType.required - Invoice Type option - eg: servicetax,commercial
 * @property {string} pdfPath.required
 * @property {string} repairOrderId.required
 * @property {enum} status.required - Status option - eg: final,paid,cancelled
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddRepairOrderInvoice
 * @property {Array.<RepairOrderInvoiceAddEditData>} datas.required
 */

/**
 * @typedef UpdateRepairOrderInvoice
 * @property {string} id.required
 * @property {RepairOrderInvoiceAddEditData.model} datas.required
 */