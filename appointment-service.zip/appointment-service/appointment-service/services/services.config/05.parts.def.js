/**
 * @typedef PartsData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
* @property {string} uomId.required
 * @property {string} uomName.required
 *  @property {string} uomCode.required
 * @property {integer} amount.required
 * @property {string} partGroupId.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */


/**
 * @typedef PartsSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef PartsSearchResult
 * @property {Array.<PartsData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteParts
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef PartsAddEditData
 * @property {string} code.required
 * @property {string} name.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddParts
 * @property {Array.<PartsAddEditData>} datas.required
 */

/**
 * @typedef UpdateParts
 * @property {string} id.required
 * @property {PartsAddEditData.model} data.required
 */