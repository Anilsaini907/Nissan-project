/**
 * @typedef TimeRecordingEventTypeVGroupData
 * @property {string} id.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 * @property {string} timeRecordingEventTypeGroupId.required
 * @property {string} timeRecordingEventTypeId.required
 */

/**
 * @typedef TimeRecordingEventTypeVGroupSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef TimeRecordingEventTypeVGroupSearchResult
 * @property {Array.<TimeRecordingEventTypeVGroupData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteTimeRecordingEventTypeVGroup
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef TimeRecordingEventTypeVGroupAddEditData
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 */

/**
 * @typedef AddTimeRecordingEventTypeVGroup
 * @property {Array.<TimeRecordingEventTypeVGroupAddEditData>} datas.required
 */

/**
 * @typedef UpdateTimeRecordingEventTypeVGroup
 * @property {string} id.required
 * @property {TimeRecordingEventTypeVGroupAddEditData.model} data.required
 */