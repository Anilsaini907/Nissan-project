/**
 * @typedef BranchCalendarGetResponse
 * @property {string} branchName
 * @property {string} countryCode
 * @property {string} year
 * @property {string} weekRestDay
 * @property {string} nationalHolidayCount
 * @property {string} regionalHolidayCount 
 */

 /**
 * @typedef BranchHolidayModel
 * @property {string} branchId.required
 * @property {string} date.required
 * @property {string} holidayName.required
 * @property {string} workingDay.required
 * @property {string} reason
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */


 /**
 * @typedef BranchHolidayResponseModel
 * @property {string} id
 * @property {string} branchId
 * @property {string} date
 * @property {string} holidayName
 * @property {string} workingDay
 * @property {string} reason
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */

/**
 * @typedef AddBranchHoliday
 * @property {Array.<BranchHolidayModel>} datas.required
 */

/**
 * @typedef DeleteBranchHoliday
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

 /**
 * @typedef EditBranchHoliday
 * @property {string} id.required
 * @property {Array.<BranchHolidayModel>} data.required
 */
