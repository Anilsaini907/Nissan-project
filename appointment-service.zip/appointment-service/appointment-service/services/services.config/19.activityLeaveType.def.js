/**
 * @typedef ActivityLeaveTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef ActivityLeaveTypeSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef ActivityLeaveTypeSearchResult
 * @property {Array.<ActivityLeaveTypeData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteActivityLeaveType
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef ActivityLeaveTypeAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddActivityLeaveType
 * @property {Array.<ActivityLeaveTypeAddEditData>} datas.required
 */

/**
 * @typedef UpdateActivityLeaveType
 * @property {string} id.required
 * @property {ActivityLeaveTypeAddEditData.model} data.required
 */