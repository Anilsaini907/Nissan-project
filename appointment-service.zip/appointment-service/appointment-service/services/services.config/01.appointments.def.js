/**
 * @typedef AppointmentsData
 * @property {string} id.required
 * @property {string} refNo.required
 * @property {string} customerId.required
 * @property {string} assignedSAId.required
 * @property {string} branchId.required
 * @property {string} vehicleId.required
 * @property {string} appointmentDate.required
 * @property {enum} type - type option - eg: 
 * @property {string} estimatedHours
 * @property {enum} method - method option - eg: 
 * @property {enum} status.required - Status option - eg: new,pro,ro,converted
 * @property {string} remarks
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} updatedByName
 * @property {string} createdBy
 * @property {string} createdByName
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef AppointmentsSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef AppointmentsSearchResult
 * @property {Array.<AppointmentsData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteAppointments
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef AppointmentsAddEditData
 * @property {string} refNo.required
 * @property {string} customerId.required
 * @property {string} assignedSAId.required
 * @property {string} branchId.required
 * @property {string} vehicleId.required
 * @property {string} appointmentDate.required
 * @property {enum} type - type option - eg: 
 * @property {string} estimatedHours - type option - eg: 
 * @property {enum} method - method option - eg:
 * @property {string} remarks
 */

/**
 * @typedef AddAppointments
 * @property {Array.<AppointmentsAddEditData>} datas.required
 */

/**
 * @typedef UpdateAppointments
 * @property {string} id.required
 * @property {AppointmentsAddEditData.model} datas.required
 */