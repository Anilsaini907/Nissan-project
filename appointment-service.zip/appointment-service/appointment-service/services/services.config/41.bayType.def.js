/**
 * @typedef BayTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required 
 * @property {string} country.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef BayTypeSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef BayTypeSearchResult
 * @property {Array.<BayTypeData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteBayType
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef BayTypeAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {string} country.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddBayType
 * @property {Array.<BayTypeAddEditData>} datas.required
 */

/**
 * @typedef UpdateBayType
 * @property {string} id.required
 * @property {BayTypeAddEditData.model} datas.required
 */