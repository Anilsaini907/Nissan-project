/**
 * @typedef RepairOrderData
 * @property {string} id.required
 * @property {string} refNo.required
 * @property {string} customerId.required
 * @property {string} assignedSAId.required
 * @property {string} branchId.required
 * @property {string} vehicleId.required
 * @property {string} appointmentsId.required
 * @property {string} repairOrderDate.required
 * @property {enum} repairOrdertypeId - type option - eg: 
 * @property {enum} status.required - Status option - eg: new,pro,ro,converted
 * @property {string} remarks
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} updatedByName
 * @property {string} createdBy
 * @property {string} createdByName
 * @property {string} updatedAt
 * @property {string} createdAt 
 */


/**
 * @typedef RepairOrderSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef RepairOrderSearchResult
 * @property {Array.<RepairOrderData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteRepairOrder
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef RepairOrderAddEditData
 * @property {string} refNo
 * @property {string} customerId.required
 * @property {string} assignedSAId.required
 * @property {string} branchId.required
 * @property {string} vehicleId.required
 * @property {string} repairOrderDate.required
 * @property {string} repairOrderTypeId.required
 * @property {string} appointmentsId
 * @property {enum} status.required - Status option - eg: new,pro,ro,converted 
 * @property {string} remarks
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddRepairOrder
 * @property {Array.<RepairOrderAddEditData>} datas.required
 */

/**
 * @typedef UpdateRepairOrder
 * @property {string} id.required
 * @property {RepairOrderAddEditData.model} datas.required
 */