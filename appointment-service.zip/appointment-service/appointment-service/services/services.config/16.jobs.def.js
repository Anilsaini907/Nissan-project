/**
 * @typedef JobsData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
  * @property {string} uomId.required
 * @property {string} uomName.required
 *  @property {string} uomCode.required
 * @property {integer} amount.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt  
 */


/**
 * @typedef JobsSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef JobsSearchResult
 * @property {Array.<JobsData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteJobs
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef JobsAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddJobs
 * @property {Array.<JobsAddEditData>} datas.required
 */

/**
 * @typedef UpdateJobs
 * @property {string} id.required
 * @property {JobsAddEditData.model} data.required
 */