/**
 * @typedef YearlyCalendarWeeklyRestDaySearch
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef YearlyCalendarWeeklyRestDaySearchResult
 * @property {Array.<YearlyCalendarWeeklyRestDayData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

 /**
 * @typedef YearlyCalendarWeeklyRestDayData
 * @property {string} id.required
 * @property {string} stateId.required
 * @property {string} stateName
 * @property {string} stateCode
 * @property {string} day.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 * @property {string} yearlyCalendarId.required
 */

/**
 * @typedef AddYearlyCalendarWeeklyRestDay
 * @property {Array.<YearlyCalendarWeeklyRestDayAddEditData>} yearlyCalendarWeeklyRestDay.required
 */

/**
 * @typedef UpdateYearlyCalendarWeeklyRestDay
 * @property {string} id.required
 * @property {YearlyCalendarWeeklyRestDayAddEditData.model} yearlyCalendarWeeklyRestDay.required
 */

 /**
 * @typedef DeleteYearlyCalendarWeeklyRestDay
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef YearlyCalendarWeeklyRestDayAddEditData
 * @property {string} stateId.required
 * @property {string} day.required
 * @property {string} yearlyCalendarId.required
 */