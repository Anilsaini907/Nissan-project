
/**
 * @typedef ActivityCostTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} countryId.required
 * @property {string} uomId.required
 * @property {string} name.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt  
 */


/**
 * @typedef ActivityCostTypeSearch
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef ActivityCostTypeSearchResult
 * @property {Array.<ActivityCostTypeData>} rows.required
 * @property {number} count.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 * @property {Array.<SearchData>} search
 * @property {Array.<FilterData>} filter
 */

/**
 * @typedef DeleteActivityCostType
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef ActivityCostTypeAddEditData
 * @property {string} code.required
 * @property {string} name.required 
 * @property {string} countryId.required
 * @property {string} uomId.required
 * @property {enum} status.required - Status option - eg: enabled,disabled,pending
 * @property {boolean} deleted.required
 */

/**
 * @typedef AddActivityCostType
 * @property {Array.<ActivityCostTypeAddEditData>} datas.required
 */

/**
 * @typedef UpdateActivityCostType
 * @property {string} id.required
 * @property {ActivityCostTypeAddEditData.model} data.required
 */