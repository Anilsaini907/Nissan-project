const JobDataUploadError = require('@driveit/driveit-databases/databases/serviceMaster').JobDataUploadError;
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const request = require('request');
const Excel = require('exceljs')

const authCache = require('../cache-request/auth-api');
const topicSeries = require('../../utilities/topicSeries');
class Functions {
    
    static async search(page, limit, order, searches, filter, fileUrl, showAll = false, distKeys = null, searchOrCond = false) {
        let pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        let orderBy = [order.columnName, order.direction];
        

        const JobDataUploadRes = JobDataUploadError.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        

        const fileData = request.get(fileUrl);
        const workbook = new Excel.Workbook();
        let buffers = [];
        let data = [];
    
        fileData.on('data', function (data) { buffers.push(data); });
        fileData.on('end', async () => {
            var buffer = Buffer.concat(buffers);
            await workbook.xlsx.load(buffer);
            workbook.eachSheet(function(worksheet, sheetId) {
                var worksheet = workbook.getWorksheet(sheetId);
                // ...
                let rowData = []
                let rowHeader;
                worksheet.eachRow(async (row, rowNum) => {
                    if(rowNum == 1){
                        rowHeader = row.values;
                    }
                    if(rowHeader  && rowNum != 1){
                        let obj = {};
                        rowHeader.forEach((data, index) => {
                            obj[data] = row.values[index];
                        });
                        rowData.push(obj);
                    }
                });
                data[worksheet.name] = rowData;
              });
              
            Promise.all([JobDataUploadRes]).then( ([result]) => {
                return res.status(200).send({
                    data : data,
                    jobDataUploadRes: result
                });
            });

            
            // let totalSuccessCounts = 0;
            // let totalErrorCounts = 0;
            // let errors = [];
    
            // ({ status, errorObj, successCounts, errorCounts } = await functions.uploadJobs(workbook.getWorksheet(sheetNames.job), userInfo))
    
            // totalSuccessCounts += successCounts;
            // totalErrorCounts += errorCounts;
            // errors = [ ...errorObj ]
    
            // if (!status) {
            //     jobDataUploadPayload.status = "failed";
            // }
    
            // ({ status, errorObj, successCounts, errorCounts } = await functions.uploadJobServiceModels(workbook.getWorksheet(sheetNames.serviceModel), userInfo));
    
            // totalSuccessCounts += successCounts;
            // totalErrorCounts += errorCounts;
            // errors = [...errors, ...errorObj]
    
            // if (!status) {
            //     jobDataUploadPayload.status = "failed";
            // }
    
            // jobDataUploadPayload.uploadEndTime = new Date();
            // jobDataUploadPayload.successCounts = totalSuccessCounts;
            // jobDataUploadPayload.errorCounts = totalErrorCounts;
            // jobDataUploadObj = await jobDataUpload.add(jobDataUploadPayload, userInfo.id, req.header);
            
            // if (jobDataUploadObj.status === 'failed') {
            //     await jobDataUploadError.addMany(errors, userInfo.id, jobDataUploadObj.id);
            // }
    
            // return res.status(200).send(jobDataUploadObj);
        });

    }
    
    static async addMany(datas, who, jobDataUploadId) {
        _.forEach(datas, (data) => {
            data.jobDataUploadId = jobDataUploadId
            Functions.add(data, who).catch((error) => {
                return errorDef.compileError(error);
            });
        });
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        };

        return JobDataUploadError.addRecord(record);
    }

    static async getGenerateMultipleCode(headers, howMany) {
        // Comment out - because not exist this method anymore, please try another later
        // let code = "JobDataUploadError";
        // return topicSeries.generateMultipleSeries(code, headers, howMany).then((s) => {
        //     if (s.status && s.code && s.message) {
        //         return Promise.reject(s);
        //     } else {
        //         return s;
        //     }

        // }).catch(function (err) {
        //     return Promise.reject(err);
        // });

        return Promise.reject([]);
    }

    static async update(id, education, who) {
        const where = {
            id
        };
        education['updatedBy'] = who;
        education['id'] = id;

        return JobDataUploadError.updateRecord(education, where).then((results) => {
            console.log(results);
            return JobDataUploadError.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        };

        if (option === 'hard') {
            return JobDataUploadError.deleteRecord(where).then((results) => {
                return JobDataUploadError.getOne(where);
            });
        } else if (option === 'soft') {
            const education = {
                deleted: true,
                updatedBy: who
            };

            return JobDataUploadError.updateRecord(education, where).then((results) => {
                return JobDataUploadError.getOne(where);
            });
        } else if (option === 'restore') {
            const education = {
                deleted: false,
                updatedBy: who
            };

            return JobDataUploadError.updateRecord(education, where).then((results) => {
                return JobDataUploadError.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;