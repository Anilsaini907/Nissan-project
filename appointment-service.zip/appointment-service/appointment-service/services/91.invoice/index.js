const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');

/**
 * Search Invoice, including contract invoice and repair order invoice
 * 
 * @route POST /invoice/search
 * @operationId InvoiceSearch
 * @group Invoice API
 * @param {InvoiceSearch.model} InvoiceSearch.body
 * @returns {InvoiceSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
  const page = req.body.page;
  const limit = req.body.limit;
  const order = req.body.order;
  const search = req.body.search;
  const filter = req.body.filter;

  const attribute = req.body.attribute;

  const showAll = req.body.showAll ? req.body.showAll : false;
  const distKeys = req.body.distKeys ? req.body.distKeys : null;
  const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

  if (search) {
    search.forEach((searchObj) => {
      errorDef.parameterHandler([searchObj.colId, searchObj.text]);
    })
  }

  errorDef.parameterHandler([page, limit, order]);
  errorDef.parameterHandler([order.columnName, order.direction]);

  return functions.search(page, limit, order, search, filter, attribute, showAll, distKeys, searchOrCond)
    .then(resp => res.status(200).send({
      ...resp,
      page,
      limit,
      order,
      search,
      filter,
      attribute
    }))
    .catch(reason => next(reason));
});

module.exports = router;