const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

/**
 * Get Billing Dates
 * 
 * @route POST /contractInvoice/getBillingDates
 * @operationId ContractInvoiceGetBillingDates
 * @group Contract Invoice API
 * @param {GetBillingDate.model} GetBillingDate.body
 * @returns { BillingDateData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/getBillingDates', async function (req, res, next) {
  const headers = req.headers;

  errorDef.parameterHandler(req.body.contractId);

  return functions.getBillingDates(req.body.contractId, headers)
    .then((response) => {
      if (!response) {
        throw errorDef.NOT_FOUND
      }
      return res.status(200).send(response);
    })
    .catch((reason) => next(reason));
});

/**
 * Get Billing Invoice
 * 
 * @route POST /contractInvoice/getBillingInvoice
 * @operationId ContractInvoiceGetBillingInvoice
 * @group Contract Invoice API
 * @param {GetBillingInvoice.model} GetBillingInvoice.body
 * @returns { BillingInvoiceData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/getBillingInvoice', async function (req, res, next) {
  const headers = req.headers;

  errorDef.parameterHandler(req.body.contractId);

  return functions.getBillingInvoice(req.body, headers)
    .then((response) => {
      if (!response) {
        throw errorDef.NOT_FOUND
      }
      return res.status(200).send(response);
    })
    .catch((reason) => next(reason));
});

/**
 * Preview Invoice
 * 
 * @route POST /contractInvoice/preview
 * @operationId ContractInvoicePreview
 * @group Contract Invoice API
 * @param {PreviewContractInvoice.model} PreviewContractInvoice.body
 * @returns { PreviewContractInvoiceResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/preview', async function (req, res, next) {
  const headers = req.headers;

  errorDef.parameterHandler(req.body.data.contractId);

  const userInfo = await errorDef.userInfoHandler(req)
    .catch(err => {
      console.error(err);
      return next(err);
    });

  if (userInfo) {
    return functions.preview(req.body.data, userInfo.id)
      .then((response) => {
        if (!response) {
          throw errorDef.NOT_FOUND
        }
        return res.status(200).send(response);
      })
      .catch((reason) => next(reason));
  }
});

/**
 * Generate Invoice
 * 
 * @route POST /contractInvoice/generate
 * @operationId ContractInvoiceGenerate
 * @group Contract Invoice API
 * @param {GenerateContractInvoice.model} GenerateContractInvoice.body
 * @returns { GenerateContractInvoiceResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/generate', async function (req, res, next) {
  const headers = req.headers;
  const contractInvoices = req.body.datas;

  errorDef.parameterHandler(contractInvoices);

  try {
    _.forEach(contractInvoices, (contractInvoice) => {
      errorDef.parameterHandler([
        contractInvoice.id,
        contractInvoice.attentionTo,
        contractInvoice.department
      ]);
    });
  } catch (err) {
    console.error(err);
    return next(err);
  }

  const userInfo = await errorDef.userInfoHandler(req)
    .catch(err => {
      console.error(err);
      return next(err);
    });

  if (userInfo) {
    return functions.generate(contractInvoices, userInfo.id, headers)
      .then((response) => {
        if (!response) {
          throw errorDef.NOT_FOUND
        }
        return res.status(200).send(response);
      })
      .catch((reason) => next(reason));
  }
});

/**
 * Cancel Invoice
 * 
 * @route POST /contractInvoice/cancel
 * @operationId ContractInvoiceCancel
 * @group Contract Invoice API
 * @param {CancelContractInvoice.model} CancelContractInvoice.body
 * @returns { CancelContractInvoiceResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/cancel', async function (req, res, next) {
  const headers = req.headers;
  errorDef.parameterHandler(req.body.id);
  errorDef.parameterHandler(req.body.invoiceDate);

  const userInfo = await errorDef.userInfoHandler(req)
    .catch(err => {
      console.error(err);
      return next(err);
    });

  if (userInfo) {
    return functions.cancel(req.body, userInfo.id, headers)
      .then((response) => {
        if (!response) {
          throw errorDef.NOT_FOUND
        }
        return res.status(200).send(response);
      })
      .catch((reason) => next(reason));
  }
});

/**
 * View Invoice
 * 
 * @route POST /contractInvoice/view
 * @operationId ContractInvoiceView
 * @group Contract Invoice API
 * @param {ViewContractInvoice.model} ViewContractInvoice.body
 * @returns { ViewContractInvoiceResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/view', async function (req, res, next) {
  const headers = req.headers;

  errorDef.parameterHandler(req.body.id);

  return functions.view(req.body.id, headers)
    .then((response) => {
      if (!response) {
        throw errorDef.NOT_FOUND
      }
      return res.status(200).send(response);
    })
    .catch((reason) => next(reason));
});

/**
 * Search Contract Invoice
 * 
 * @route POST /contractInvoice/search
 * @operationId ContractInvoiceSearch
 * @group Contract Invoice API
 * @param {ContractInvoiceSearch.model} ContractInvoiceSearch.body
 * @returns {ContractInvoiceSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
  const page = req.body.page;
  const limit = req.body.limit;
  const order = req.body.order;
  const search = req.body.search;
  const filter = req.body.filter;
  
  const showAll = req.body.showAll ? req.body.showAll : false;
  const distKeys = req.body.distKeys ? req.body.distKeys : null;
  const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

  if (search) {
    search.forEach((searchObj) => {
      errorDef.parameterHandler([searchObj.colId, searchObj.text]);
    })
  }

  errorDef.parameterHandler([page, limit, order]);
  errorDef.parameterHandler([order.columnName, order.direction]);

  return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond)
    .then(resp => res.status(200).send({
      ...resp,
      page,
      limit,
      order,
      search,
      filter
    }))
    .catch(reason => next(reason));
});

module.exports = router;