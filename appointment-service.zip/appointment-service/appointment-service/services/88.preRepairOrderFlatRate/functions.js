const preRepairOrderFlatRate = require('@driveit/driveit-databases/databases/serviceMaster').PreRepairOrderFlatRate;
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
        

        return await preRepairOrderFlatRate.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async addMany(datas, who) {
        let promises = [];

        for (let t = 0; t < datas.length; t++) {
            let data = datas[t];

            //else multiple
            promises.push(Functions.add(data, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        }


        return Promise.all(promises);
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        }

        return preRepairOrderFlatRate.addRecord(record);
    }

    static async update(id, education, who) {
        const where = {
            id
        }
        education['updatedBy'] = who;
        education['id'] = id;

        return preRepairOrderFlatRate.updateRecord(education, where).then((results) => {
            return preRepairOrderFlatRate.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return preRepairOrderFlatRate.deleteRecord(where).then((results) => {
                return preRepairOrderFlatRate.getOne(where);
            });
        } else if (option === 'soft') {
            const education = {
                deleted: true,
                updatedBy: who
            }

            return preRepairOrderFlatRate.updateRecord(education, where).then((results) => {
                return preRepairOrderFlatRate.getOne(where);
            });
        } else if (option === 'restore') {
            const education = {
                deleted: false,
                updatedBy: who
            }

            return preRepairOrderFlatRate.updateRecord(education, where).then((results) => {
                return preRepairOrderFlatRate.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;