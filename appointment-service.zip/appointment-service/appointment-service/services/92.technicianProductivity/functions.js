const TechnicianProductivity = require('@driveit/driveit-databases/databases/serviceMaster').TechnicianProductivity;
const technicianProductivityModel = require('@driveit/driveit-databases/databases/serviceMaster/models/100.technicianProductivity');
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');

const customerCache = require('../cache-request/customer-api');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
        

        return TechnicianProductivity.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async addMany(technicianProductivityObj, who) {
        return technicianProductivityModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(technicianProductivityObj, (addTechnicianProductivityObj) => {
                const p = technicianProductivityModel.addNew(addTechnicianProductivityObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }


    static async add(data, who) {

        let record = {
            ...data
        }

        await technicianProductivityModel.getAll({repairOrderId: data.repairOrderId, repairOrderFlatRateId: data.repairOrderFlatRateId}).then(found => {
            if(found && found.length > 0) {
                console.log(found);
                const lastData = found[found.length - 1];
                if (data.timeRecordingEventTypeName === "BREAK" && lastData.timeRecordingEventTypeName == "START WORK ON JOB") {
                    // Update endTime on START WORK ON JOB
                    const updateData = {
                        endDate: data.workDate,
                        endTime: data.startTime
                    }
                    const where = {
                        id: lastData.id
                    }
                    technicianProductivityModel.updateRecord(updateData, where);
                } else if (data.timeRecordingEventTypeName === "START WORK ON JOB" && lastData.timeRecordingEventTypeName == "BREAK") {
                    // Update endTime on BREAK
                    const updateData = {
                        endDate: data.workDate,
                        endTime: data.startTime
                    }
                    const where = {
                        id: lastData.id
                    }
                    technicianProductivityModel.updateRecord(updateData, where);
                } else if (data.timeRecordingEventTypeName === "FINISH WORK ON JOB" && lastData.timeRecordingEventTypeName === "START WORK ON JOB") {
                    // Update endTime on START WORK ON JOB
                    const updateData = {
                        endDate: data.workDate,
                        endTime: data.startTime
                    }
                    const where = {
                        id: lastData.id
                    }
                    record = { 
                        ...data,
                        endTime: data.startTime,
                        endDate: data.workDate
                    }
                    technicianProductivityModel.updateRecord(updateData, where);
                }
            }
        })
        .catch((reason) => {
            next(reason);
        });

        return technicianProductivityModel.addRecord(record);
    }

    static async update(id, education, who) {
        const where = {
            id
        }
        education['updatedBy'] = who;
        education['id'] = id;

        return TechnicianProductivity.updateRecord(education, where).then((results) => {
            return TechnicianProductivity.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return TechnicianProductivity.deleteRecord(where).then((results) => {
                return TechnicianProductivity.getOne(where);
            });
        } else if (option === 'soft') {
            const education = {
                deleted: true,
                updatedBy: who
            }

            return TechnicianProductivity.updateRecord(education, where).then((results) => {
                return TechnicianProductivity.getOne(where);
            });
        } else if (option === 'restore') {
            const education = {
                deleted: false,
                updatedBy: who
            }

            return TechnicianProductivity.updateRecord(education, where).then((results) => {
                return TechnicianProductivity.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;