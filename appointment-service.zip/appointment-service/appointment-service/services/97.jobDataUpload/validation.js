const { check, validationResult } = require('express-validator');
const errorDef = require('../services.config/errorDef');

const sheetDetailValidation = () => {
    return [
        check('id', 'Job Data Upload Id is empty').not().isEmpty(),
        check('id', "Job Data Upload Id must be string").isString()
    ]
}


const validate = (req, res, next) => {
    const errors = validationResult(req)
    if (errors.isEmpty()) {
        return next()
    }
    const extractedErrors = []
    errors.array().map(err => extractedErrors.push({ [err.param]: err.msg }))

    if (extractedErrors.length > 0) {
        let err = errorDef.INVALID_PARAMETER;
        err.errors = extractedErrors;
        throw err
    } else {
        next();
    }
}
module.exports = {
    sheetDetailValidation,
    validate,
}