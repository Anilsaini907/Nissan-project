const express = require('express');
const router = express.Router();
const monitorFunctions = require('./functions');
const errorDef = require('../services.config/errorDef');


/**
 * Testing api to check condition of auth service
 * 
 * @route GET /monitor/health
 * @operationId getHealth
 * @group Monitor - API testing checker
 * @returns {string} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.get('/health', function (req, res, next) {

    return monitorFunctions.healthChecker()
        .then((result) => {
            return res.send({
                code: 'OK',
                message: result
            });



        }).catch((reason) => {
            let errorResponse = errorDef.DATABASE_ISSUE;
            errorResponse.error = reason;
            return res.status(400).send(errorResponse);
        })
});

/**
 * Testing api to check condition of auth service
 * 
 * @route POST /monitor/health
 * @operationId postHealth
 * @group Monitor - API testing checker
 * @returns {string} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/health', function (req, res, next) {
    return monitorFunctions.healthChecker()
        .then((result) => {
            return res.send({
                code: 'OK',
                message: result
            });



        }).catch((reason) => {
            let errorResponse = errorDef.DATABASE_ISSUE;
            errorResponse.error = reason;
            return res.status(400).send(errorResponse);
        })
});




module.exports = router;