const NodeCache = require ('node-cache');
// const ttl = 60 * 60 * 1; // cache for 1 Hour
const ttl = 60 * 10 * 1; // cache for 10 mins
  
class CacheService {
  
  constructor(ttlSeconds = ttl) {
    this.cache = new NodeCache({ stdTTL: ttlSeconds, checkperiod: ttlSeconds * 0.2, useClones: false });
  }

  get(key, storeFunction) {
    const value = this.cache.get(key);
    if (value) {
      return Promise.resolve(value);
    }

    return storeFunction.then((result) => {
      this.cache.set(key, result);
      return result;
    });
  }

  del(keys) {
    this.cache.del(keys);
  }

  /** get all cache key starting with startStr and delete */
  delStartWith(startStr = '') {
    if (!startStr) {
      return;
    }

    const keys = this.cache.keys();
    for (const key of keys) {
      if (key.indexOf(startStr) === 0) {
        this.del(key);
      }
    }
  }

  flush() {
    this.cache.flushAll();
  }

  getAllKeys() {
    return this.cache.keys();
  }

  setObj(key, obj) {
    this.cache.set(key, obj);
  }
}


module.exports = CacheService;