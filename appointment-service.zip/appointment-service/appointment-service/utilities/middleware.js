const errorDef = require('../services/services.config/errorDef');

const validationId = (req, res, next) => {
    const { id } = req.body;

    errorDef.parameterHandler([id]);
    return next();
}

const validateSearch = (req, res, next) => {
    const { search, filter, page, limit, order } = req.body;

    if (search) {
        search.forEach(searchObj => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }

    if (filter) {
        filter.forEach(filterObj => {
            errorDef.parameterHandler([filterObj.colId, filterObj.text]);
        });
    }

    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return next();
}
module.exports = {
    validateSearch,
    validationId
} 