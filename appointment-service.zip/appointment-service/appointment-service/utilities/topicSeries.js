var request = require('request-promise');
const config = require('config');
const GeneralAPI = require('../services/cache-request/general-api');

function generateSeries(code, headers) {

    const theHeader = {
        'Authorization': headers.authorization,
        'Content-Type': 'application/json',
    };

    return request(config.topicSeries.hostname + "/" + code, {
        headers: theHeader
    });
}

async function generateAutomotiveSeries(code, headers) {
    const handle = (promise) => {
        return promise
            .then(data => ([data, undefined]))
            .catch(error => Promise.resolve([undefined, error]));
    };

    const theHeader = {
        'Authorization': headers.authorization,
        'Content-Type': 'application/json',
    };

    const [serieNumber, serError] = await handle(request(config.topicSeries.hostname + "/" + code, { headers: theHeader }));

    if (serieNumber) {
        return Promise.resolve(serieNumber);
    }

    if (serError.name == 'RequestError') {
        return Promise.reject(serError);
    }

    const [serieCode, serieCodeError] = await handle(addCode(headers.authorization, code));
    if (serieCodeError) {
        return Promise.reject(serieCodeError);
    }

    return request(config.topicSeries.hostname + "/" + code, { headers: theHeader });
}

function addCode(token, code) {
    let prefix, startNumber, endNumber;
    switch (code) {
        case config.topicSeries.appointmentCode:
            prefix = 'APT';
            startNumber = "000000000";
            endNumber = "999999999";
            break;
        case config.topicSeries.repairOrderCode:
            prefix = 'RO';
            startNumber = "000000000";
            endNumber = "999999999";
            break;
        case config.topicSeries.appointmentCodeV2:
        case config.topicSeries.repairOrderInvoiceCode:
            prefix = '';
            startNumber = "0000000";
            endNumber = "9999999";
            break;
        case config.topicSeries.paymentCode:
            prefix = '';
            startNumber = "000000000";
            endNumber = "999999999";
            break;
        default:
            prefix = '00';
            startNumber = "000000000";
            endNumber = "999999999";
            break;
    }
    let topicSeries = [{
        code,
        prefix,
        startNumber,
        currentNumber: startNumber,
        endNumber,
        status: "enabled",
        yearSuffix: false,
        resetPerYr: false
    }];

    let options = {
        endpoint: '/topic-series/add',
        method: 'PUT'
    }
    return GeneralAPI.generalService(token, {
        topicSeries
    }, options);
}

module.exports = {
    generateSeries,
    generateAutomotiveSeries,
    addCode
}