module.exports = class DupKiller {

    constructor(timeout = 30000) {
        this._ids = [];
        this._timeout = timeout;
    }
    add(id) {
        if (this._ids.find(x => x.id == id)) {
            return false;
        } else {
            this._ids.push({
                id,
                timeout: setTimeout(() => {
                    return this.remove(id)
                }, this._timeout)
            });

            return true;
        }
    }
    check(id) {
        if (this._ids.find(x => x.id == id)) {
            return false;
        } else {
            return true;
        }
    }
    getIds(id = null) {
        if(id){
            return this._ids.find(x => x.id == id);
        }
        return this._ids;
    }
    remove(id) {
        clearTimeout(this._ids.find(x => x.id == id).timeout);
        this._ids = this._ids.filter(x => x.id != id);
    }

}