const DupKiller = require('./index');
const partStatusUpdateDK = new DupKiller();






(function myLoop(i) {
    setTimeout(function() {
        console.log(partStatusUpdateDK.add('asdasdasd'));             
      if (--i) myLoop(i);   //  decrement i and call myLoop again if i > 0
    }, 3000)
  })(10);  

  (function myLoop(i) {
    setTimeout(function() {
        console.log(partStatusUpdateDK.add('123123'));             
      if (--i) myLoop(i);   //  decrement i and call myLoop again if i > 0
    }, 2000)
  })(10); 